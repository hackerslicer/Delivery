What is this software ?
This software is absolutely free, without any restriction.
It is intended to protect workstations and servers connected either to the Internet or a local network from any kind of malware. This program does not analyze any log file like most IDS or IPS programs do, because such a process is slow and can be forged. Everything is in memory. This means that if you reboot your machine, there is no active track of this program left. The basic assumption is that whatever you do, your system will be compromised, by a zero day exploit, a user fault, or a back-door, state enforced, installed by a hardware or software company. So this program goes to the basics, where the very truth is: the network traffic incoming and outgoing. The challenge is to make the difference between legitimate user actions, and rogue processes. This cannot be perfect, since the resources of the hackers, especially state owned, are unlimited, but this program does pretty well in most situations. We are still in a world were the rules of the game allow one individual to be stronger than a stupid state.

Technical requirements: 
This is a linux program tested on Ubuntu, Mint, Debian and Arch distributions. It requires curl to be installed. While active, it outputs a summary of every action on the console. It generates also a log file (one per month) in the same directory where the program is located, including detailed payload (rogue program) received. Some text editors do not like hexadecimal characters, therefore this log file is best viewed by an appropriate hexadecimal editor like Bless Hex Editor for example.

Installation:
1 - Create a directory wherever you want, ie MyDirectory.
2 - Uncompress the archive in that directory : you will find there the program (Hacker), the config file (Hconfig.txt), the starting script (SecureServer.sh) and a directory (Safe). 
    To secure the installation you should rename the program Hacker to whatever you want, and modify the last line in the script SecureServer.sh to the absolute path of the new name of this program. (this is to prevent a back-door program to identify and kill Hacker too easily: advanced users can install it as a starting process with respawn option). The Directory Safe is intended to harbor your private files that you do not want, in any case, to be stolen by a remote access. The config file, Hconfig.txt, is a text file read at the beginning of the the program, and the values can be changed if you feel that you can in this way improve the difference between legitimate and rogue actions.
3 - Start the script by typing in a console: sudo sh /home/username/MyDirectory/SecureFirewall.sh (or any other path to the starting script).

Future developments: automatic retaliation by disrupting the hardware of the offending machines. Comments and other contributions are welcome.
mail: hackerslicer@tutanota.com









