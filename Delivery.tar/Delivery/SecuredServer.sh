#!/bin/bash          
echo "Secured Server" 

# Flush INPUT/OUTPUT/FORWARD chains
sudo iptables -F INPUT
sudo iptables -F OUTPUT
sudo iptables -F FORWARD

# Drop invalid packets
sudo iptables -A INPUT -m conntrack --ctstate INVALID -j DROP

# DROP specific
sudo iptables -I OUTPUT -p tcp --tcp-flags ALL RST,ACK -j DROP

sudo iptables -A INPUT -p udp --dport 137 -j DROP
sudo iptables -A INPUT -p udp --dport 138 -j DROP
sudo iptables -A INPUT -p udp --dport 139 -j DROP
sudo iptables -A INPUT -p udp --dport 445 -j DROP
sudo iptables -A INPUT -p tcp --dport 139 -j DROP
sudo iptables -A INPUT -p tcp --dport 445 -j DROP


# Accept everthing on loopback
sudo iptables -A INPUT  -i lo -j ACCEPT
sudo iptables -A OUTPUT -o lo -j ACCEPT

# Accept packets for established connections
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
sudo iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# Pass incoming SSH
sudo iptables -A INPUT -i eth0 -p tcp --dport 22 -j ACCEPT

# Pass ftp
sudo iptables -A INPUT -p tcp --dport 21 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 20 -j ACCEPT
sudo iptables -A PREROUTING -t raw -p tcp --dport 21 -j CT --helper ftp

# Accept outgoing DNS
sudo iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT
sudo iptables -A OUTPUT -p udp --dport 53 -j ACCEPT

# Accept outgoing NTP
sudo iptables -A OUTPUT -p tcp --dport 123 -j ACCEPT
sudo iptables -A OUTPUT -p udp --dport 123 -j ACCEPT

# Accept HTTP/S
sudo iptables -A OUTPUT -p tcp --dport 80  -j ACCEPT
sudo iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 80  -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT

# Accept outgoing SSH
sudo iptables -A OUTPUT -p tcp --dport 22  -j ACCEPT

# Accept NX
sudo iptables -A OUTPUT -p tcp --dport 4000  -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 4000  -j ACCEPT

# Accept outgoing ICMP
#iptables -A OUTPUT -p icmp -j ACCEPT

# Drop everything else
sudo iptables -P INPUT   DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT  DROP

sudo /home/username/MyDirectory/Hacker



